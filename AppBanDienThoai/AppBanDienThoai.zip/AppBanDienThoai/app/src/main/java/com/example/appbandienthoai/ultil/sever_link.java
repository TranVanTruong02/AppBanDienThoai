package com.example.appbandienthoai.ultil;

public class sever_link {
    //Phân giải tên localhost ra để thiết bị hiểu được địa chỉ ip
    //Địa chỉ ip được lấy thông tin từ thiết bị kết nối, vì khi kết nốit cả 2 thiết bị phải chung 1 địa chỉ mạng
    public static String localhost = "192.168.202.10"; //Đây chính là địa chỉ localhost được phân giải
    public static String duongdanLoaisp = "http://" + localhost + "/server/AppBanDienThoai/loaisanpham.php";
    //http://192.168.168.10/server/AppBanDienThoai/loaisanpham.php

    public static String duongdanSanpham = "http://" + localhost + "/server/AppBanDienThoai/sanphammoinhat.php";
    //http://192.168.105.10/server/AppBanDienThoai/sanpham.php

    public static String duongdanSanphamDienThoai = "http://" + localhost + "/server/AppBanDienThoai/sanpham.php?page=";
    //Lưu ý địa chỉ ipv4 thay đổi liên tục-phiền ghê
    //http://192.168.202.10/server/AppBanDienThoai/sanphammoinhat.php

}
