package com.example.appbandienthoai.activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ViewFlipper;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.appbandienthoai.R;
import com.example.appbandienthoai.adapter.LoaiSanPhamAdapter;
import com.example.appbandienthoai.adapter.SanPhamAdapter;
import com.example.appbandienthoai.molder.GioHang;
import com.example.appbandienthoai.molder.LoaiSanPham;
import com.example.appbandienthoai.molder.SanPham;
import com.example.appbandienthoai.ultil.Chech_internet;
import com.example.appbandienthoai.ultil.sever_link;
import com.google.android.material.navigation.NavigationView;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    //Khai báo biến giao diện
    DrawerLayout drawerLayout_main;
    Toolbar toolbar_main;
    ViewFlipper viewFlipper_main;
    RecyclerView recyclerView_main;
    NavigationView navigationView_main;
    ListView listView_main;
    //Thao tác cho toolbar
    ArrayList<LoaiSanPham> arrayLoaisp = null;
    LoaiSanPhamAdapter adapterLoaisp;
    // Khai báo các thuộc tính của loại sản phẩm
    int id = 0;
    String tenLoaiSP = "";
    String anhSP = "";
    //Truyền dữ liệu sản phẩm đến RecyclerView
    ArrayList<SanPham> listSP;
    SanPhamAdapter sanPhamAdapter;

    //-----------Khởi tạo 1 mảng giỏ hàng toàn cục để giữ liệu không bị mất đi khi ta chuyển màn hình
    public static ArrayList<GioHang> arrayGioHang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Anhxa_Main();
        //Nếu như có kết nối internet ta mới thực hiện
        if(Chech_internet.haveNetWorkConnection(MainActivity.this)){ //getApplicationContext gọi đến màn hình này
            //Bắt sự kiện cho Toolbar
            Actionbar();
            //Tạo slideshow
            ActionFlipper();
            //đổ gữ liệu loại sản phầm cho toolbar
            GetLoaiSP();
            //Đổ dữ liệu lên RecyclerView
            GetSanPham();
            //Chuyển màn hình cho thanh Menu
            ManHinh_ItemsMenu();

        }
        else { //ngược lại ta thông báo không có internet
            Chech_internet.ShowToast(MainActivity.this, "Không có kết nối Internet!");
            finish(); // dừng màn hình này lại
        }
    }
    //Gọi ra menu Giỏ hàng
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }
    //Bắt sự kiện khi click vào menu Giỏ hàng
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_giohang:
                Intent intent = new Intent(getApplicationContext(), GioHangActivity.class);
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }

    private void Anhxa_Main(){
        drawerLayout_main = (DrawerLayout) findViewById(R.id.drawerlayout_main);
        toolbar_main = (Toolbar) findViewById(R.id.toolbar_main);
        viewFlipper_main = (ViewFlipper) findViewById(R.id.viewflipper_main);
        recyclerView_main = (RecyclerView) findViewById(R.id.recyclerview_main);
        navigationView_main = (NavigationView) findViewById(R.id.nagrationview_main);
        listView_main = (ListView) findViewById(R.id.listview_main);
        //Ánh xạ cho toolbar
        arrayLoaisp = new ArrayList<>();
        arrayLoaisp.add(new LoaiSanPham(0, "Trang Chính", "https://cdn-icons-png.flaticon.com/512/3259/3259023.png"));
        adapterLoaisp = new LoaiSanPhamAdapter(arrayLoaisp, getApplicationContext());
        //Đổ dữ liệu vào listview
        listView_main.setAdapter(adapterLoaisp);
        //Truyền dữ liệu sản phẩm đến RecyclerView
        listSP = new ArrayList<>();
        //Truyền vào adapter màn hình và mảng arraylist
        sanPhamAdapter = new SanPhamAdapter(getApplicationContext(),listSP);
        //Ta sử dụng recyslerview hiện thị dưới dạng 2 cột
        recyclerView_main.setHasFixedSize(true);
        //Truyền vào màn hình và muốn hiển thị ở 2 cột
        recyclerView_main.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));
        recyclerView_main.setAdapter(sanPhamAdapter);

        //------------------Cấp phát vùng bộ nhớ cho mảng giỏ hàng
        if(arrayGioHang != null){}
        else {
            arrayGioHang = new ArrayList<>();
        }
    }

    //Menu
    private void  Actionbar(){
        //Hàm hỗ trợ toolbar
        setSupportActionBar(toolbar_main);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //Tạo icon home
        toolbar_main.setNavigationIcon(android.R.drawable.ic_menu_sort_by_size);
        //Mở ra menu
        toolbar_main.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawerLayout_main.openDrawer(GravityCompat.START); //Nhảy menu ra giữa
            }
        });
    }

    //Quảng Cáo
    private void ActionFlipper() {
        //Mảng lưu đường dẫn của các tấm hình
        ArrayList<Integer> advertissement = new ArrayList<>();
        advertissement.add(R.drawable.slideshow_1);
        advertissement.add(R.drawable.slideshow_2);
        advertissement.add(R.drawable.slideshow_3);
        advertissement.add(R.drawable.slideshow_4);
        advertissement.add(R.drawable.slideshow_5);
        advertissement.add(R.drawable.slideshow_6);
        //Gán link vào imageview
        for (int i = 0; i < advertissement.size(); i++) {
            ImageView imageView = new ImageView(getApplicationContext());
            Picasso.get().load(advertissement.get(i)).into(imageView);
            //Căn vừa ảnh với khung
            imageView.setScaleType(ImageView.ScaleType.FIT_XY);
            //Ép ImageView vào viewFlipper
            viewFlipper_main.addView(imageView);
        }
        //Tạo sự kiện viewFlipper tự chạy, với thời gian 5s
        viewFlipper_main.setFlipInterval(5000);
        viewFlipper_main.setAutoStart(true);
        //Truyền 2 hiệu ứng từ xml vào-Tạo đối tượng view động
        Animation animation_in = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_in_right);
        Animation animation_out = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.slide_out_right);
        //Truyền 2 animatin vào viewflipper
        viewFlipper_main.setInAnimation(animation_in);
        viewFlipper_main.setOutAnimation(animation_out);
    }

    //Đọc dữ liệu cho loại sản phẩm
    private void GetLoaiSP(){
        //Đọc đường lick, đọc đường link json
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        //Vì đường link được bọc json lên ta sử dụng JsonArrayRequest để đọc
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(sever_link.duongdanLoaisp, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Nếu có dữ liệu, thì mới đọc dữ liệu
                if(response != null){
                    //Vì phẩn tử mảng có 2 json con, nên ta sử dụng vòng for duyệt từng phần tử
                    for (int i = 0; i < response.length(); i++){
                        try {
                            //Ta đi từ jsonarray vào jsonobject theo thứ tự i
                            JSONObject jsonObject = response.getJSONObject(i);
                            //Lấy dữ liệu ra
                            id = jsonObject.getInt("id");
                            tenLoaiSP = jsonObject.getString("tenLoaiSP");
                            anhSP = jsonObject.getString("anhSP");
                            //Truyền vào theo cấu trúc vào mảng
                            arrayLoaisp.add(new LoaiSanPham(id,tenLoaiSP,anhSP));
                            //Cập nhật lại màn hình
                            adapterLoaisp.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    arrayLoaisp.add(new LoaiSanPham(3, "Liên Hệ", "https://cdn-icons-png.flaticon.com/512/3188/3188213.png"));
                    arrayLoaisp.add(new LoaiSanPham(4, "Thông Tin", "https://cdn-icons-png.flaticon.com/512/3598/3598391.png"));
                }
            }
        }, new Response.ErrorListener() { //Nếu lỗi trả về trong đây
            @Override
            public void onErrorResponse(VolleyError error) {
                //Thông báo error
                Chech_internet.ShowToast(getApplicationContext(), error.toString());
            }
        });
        //Muốn cho việc đọc dữ liệu thực hiện
        requestQueue.add(jsonArrayRequest);
    }

    //Đọc dữ liệu sản phẩm
    private void GetSanPham(){
        //Đọc nội dung trên location
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        //Đọc json
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(sever_link.duongdanSanpham, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                //Nếu như ó dữ liệu json thì mới thực hiện
                if(response != null){
                    //Khai báo các biến của sản phẩm
                    int id = 0, idsp = 0;
                    String tensp = "", motasp = "", anhsanpham = "";
                    Integer giasp = 0;
                    //Sử dụng vòng lặp for cho việc đọc dữ liệu json
                    for (int i = 0; i < response.length(); i++){
                        //Sử dụng json object để đọc dữ liệu json của từng object
                        try {
                            JSONObject jsonObject = response.getJSONObject(i);
                            id = jsonObject.getInt("id");
                            tensp = jsonObject.getString("tenSP");
                            giasp = jsonObject.getInt("giaSP");
                            anhsanpham = jsonObject.getString("anhSP");
                            motasp = jsonObject.getString("moTaSP");
                            idsp = jsonObject.getInt("idSP");
                            listSP.add(new SanPham(id, tensp, giasp, anhsanpham, motasp, idsp));
                            //Cập nhật màn hình
                            sanPhamAdapter.notifyDataSetChanged();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
        //Thực hiện requestQueue
        requestQueue.add(jsonArrayRequest);
    }
    //Sự kiện chuyển màn hình cho menu
    private void ManHinh_ItemsMenu(){
        //Sử dụng sự kiện setOnItemClickListener để chọn sự kiện cho từng Items
        listView_main.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //Sử dụng switch để chọn sự kiện
                switch (i){
                    case 0:
                        //Kiểm tra việc kết nối mạng
                        if (Chech_internet.haveNetWorkConnection(getApplicationContext())) {
                            //Khởi tạo các màn hình cần chuyển
                            Intent intent = new Intent(MainActivity.this, MainActivity.class);//Màn hình đang đứng, màn hình sẽ chuyển
                            startActivity(intent);
                        }
                        else {
                            Chech_internet.ShowToast(getApplicationContext(), "Bạn hãy kiểm tra lại kết nối!");
                        }
                        //Khi ta click lại vào menu thì nó sẽ đóng
                        drawerLayout_main.closeDrawer(GravityCompat.START);
                        break;
                    case 1:
                        if (Chech_internet.haveNetWorkConnection(getApplicationContext())) {
                            Intent intent = new Intent(MainActivity.this, DienThoaiActivity.class);
                            //Truyền id loại sản phầm qua màn hình DienThoaiActivity
                            intent.putExtra("idSP", arrayLoaisp.get(i).getId());
                            startActivity(intent);
                        }
                        else {
                            Chech_internet.ShowToast(getApplicationContext(), "Bạn hãy kiểm tra lại kết nối!");
                        }
                        drawerLayout_main.closeDrawer(GravityCompat.START);
                        break;
                    case 2:
                        if (Chech_internet.haveNetWorkConnection(getApplicationContext())) {
                            Intent intent = new Intent(MainActivity.this, LapTopActivity.class);
                            //Truyền id loại sản phầm qua màn hình LaptopActivity
                            intent.putExtra("idSP", arrayLoaisp.get(i).getId()); //lưu ý ở đây ta lấy get(i) là vì i trùng với id bên phpadmin
                            startActivity(intent);
                        }
                        else {
                            Chech_internet.ShowToast(getApplicationContext(), "Bạn hãy kiểm tra lại kết nối!");
                        }
                        drawerLayout_main.closeDrawer(GravityCompat.START);
                        break;
                    case 3:
                        if (Chech_internet.haveNetWorkConnection(getApplicationContext())) {
                            Intent intent = new Intent(MainActivity.this, LienHeActivity.class);
                            startActivity(intent);
                        }
                        else {
                            Chech_internet.ShowToast(getApplicationContext(), "Bạn hãy kiểm tra lại kết nối!");
                        }
                        drawerLayout_main.closeDrawer(GravityCompat.START);
                        break;
                    case 4:
                        if (Chech_internet.haveNetWorkConnection(getApplicationContext())) {
                            Intent intent = new Intent(MainActivity.this, ThongTinActivity.class);
                            startActivity(intent);
                        }
                        else {
                            Chech_internet.ShowToast(getApplicationContext(), "Bạn hãy kiểm tra lại kết nối!");
                        }
                        drawerLayout_main.closeDrawer(GravityCompat.START);
                        break;
                }
            }
        });
    }

}