package com.example.appbandienthoai.activity;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.example.appbandienthoai.R;
import com.example.appbandienthoai.adapter.GioHang_Adapter;
import com.example.appbandienthoai.ultil.Chech_internet;

import java.text.DecimalFormat;

public class GioHangActivity extends AppCompatActivity {
    //Khai báo biến giao diện
    TextView tvThongbaoGiohang;
    static TextView tvTongTienGiohang;
    Button btMuangayGiohang, btThemmoiGiohang;
    ListView listGiohang;
    androidx.appcompat.widget.Toolbar toolbarGiohang;
    GioHang_Adapter adapterGiohang;
    //Ở đây ta đã sử dụng mảng toàn cục được khai báo bên MainActivity
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gio_hang);
        AnhXa_GioHang();
        ToolbarGioHang();
        //Kiểm tra dữ liệu trong giỏ hàng trống hay k
        CheckGioHang();
        //Bắt sự kiện đổ dữ liệu lên listview
        DataListView();
        ClickItemsLongListView();
        //Sự kiện nút button mua ngay và tiếp tục mua
        ClickButton();
    }
    private void AnhXa_GioHang(){
        toolbarGiohang = (Toolbar) findViewById(R.id.toolbar_giohang);
        tvThongbaoGiohang = (TextView) findViewById(R.id.tv_thongbao_giohang);
        tvTongTienGiohang = (TextView) findViewById(R.id.tv_tong_gia);
        listGiohang = (ListView) findViewById(R.id.listview_giohang);
        btMuangayGiohang = (Button) findViewById(R.id.bt_muangay_giohang);
        btThemmoiGiohang = (Button) findViewById(R.id.bt_themmoi_giohang);
        adapterGiohang = new GioHang_Adapter(GioHangActivity.this, MainActivity.arrayGioHang);
        listGiohang.setAdapter(adapterGiohang);
    }
    private void ToolbarGioHang(){
        setSupportActionBar(toolbarGiohang);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbarGiohang.setNavigationIcon(R.drawable.ic_left);
        toolbarGiohang.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    //Kiểm tra dữ liệu bên trong giỏ hàng
    private void CheckGioHang(){
        //nếu như dữ liệu trống, ta cho hiện thị câu thông báo giỏ hàng trống
        if (MainActivity.arrayGioHang.size() <= 0){
            //Cập nhật lại adapter
            adapterGiohang.notifyDataSetChanged();
            tvThongbaoGiohang.setVisibility(View.VISIBLE);//Cho nó hiện ra
            listGiohang.setVisibility(View.INVISIBLE);//Cho nó ẩn đi
        }
        else {
            adapterGiohang.notifyDataSetChanged();
            tvThongbaoGiohang.setVisibility(View.INVISIBLE);
            listGiohang.setVisibility(View.VISIBLE);
        }
    }
    //Hiển thị tổng tiền
    public static void DataListView(){
        long tongtien = 0;
        for (int i = 0; i < MainActivity.arrayGioHang.size(); i++){
            tongtien += MainActivity.arrayGioHang.get(i).getGiasp();
        }
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        tvTongTienGiohang.setText(decimalFormat.format(tongtien) + " Đ");
    }
    private void ClickItemsLongListView(){
        listGiohang.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long l) {
                AlertDialog.Builder builder = new AlertDialog.Builder(GioHangActivity.this);
                builder.setTitle("Xác nhận xoá sản phẩm");
                builder.setMessage("Bạn có chắc chắn xoá sản phẩm này?");
                builder.setNegativeButton("Có", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if(MainActivity.arrayGioHang.size() <= 0){
                            tvThongbaoGiohang.setVisibility(View.VISIBLE);
                        }
                        else {
                            //Bắt vị trí theo listview
                            MainActivity.arrayGioHang.remove(position);
                            //Cập nhật lại màn hình
                            adapterGiohang.notifyDataSetChanged();
                            //Cập nhật lại tổng tiền
                            DataListView();
                            //Sau khi xoá xong nếu dữ liệu trống ta hiện thị giỏ hàng trống
                            if(MainActivity.arrayGioHang.size() <= 0){
                                tvThongbaoGiohang.setVisibility(View.VISIBLE);
                            }
                            else {
                                tvThongbaoGiohang.setVisibility(View.INVISIBLE);
                                adapterGiohang.notifyDataSetChanged();
                                DataListView();
                            }
                        }
                    }
                });
                builder.setPositiveButton("Không", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        adapterGiohang.notifyDataSetChanged();
                        DataListView();
                    }
                });
                builder.create().show();
                return true;
            }
        });
    }
    private void ClickButton(){
        btThemmoiGiohang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }
        });
        btMuangayGiohang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (MainActivity.arrayGioHang.size() > 0){
                    Intent intent = new Intent(getApplicationContext(), ThongTinKhachHangActivity.class);
                    startActivity(intent);
                }
                else {
                    Chech_internet.ShowToast(getApplicationContext(), "Giỏ hàng của bạn đang trống");
                }
            }
        });
    }


}
